// Main JS for the theme

document.addEventListener('DOMContentLoaded', function () {
    // Mobile menu toggle
    const mobileMenuButton = document.querySelector('.mobile-menu-toggle');
    const menu = document.querySelector('.main-navigation');

    if (mobileMenuButton) {
        mobileMenuButton.addEventListener('click', function () {
            menu.classList.toggle('open');
        });
    }

    // Other interactivity features can go here
});
