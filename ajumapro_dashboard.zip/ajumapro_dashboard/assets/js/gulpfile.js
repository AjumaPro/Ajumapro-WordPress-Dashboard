// gulpfile.js
const gulp = require('gulp');
const sass = require('gulp-sass')(require('sass'));
const autoprefixer = require('gulp-autoprefixer');

// Task to compile SCSS into CSS
gulp.task('sass', function () {
    return gulp.src('assets/scss/**/*.scss')  // Source of Sass files
        .pipe(sass().on('error', sass.logError))  // Compile Sass
        .pipe(autoprefixer())  // Add vendor prefixes
        .pipe(gulp.dest('assets/css'));  // Output to CSS directory
});

// Watch SCSS files for changes
gulp.task('watch', function () {
    gulp.watch('assets/scss/**/*.scss', gulp.series('sass'));
});

// Default task
gulp.task('default', gulp.series('sass', 'watch'));
