<?php
get_header(); ?>

<div class="container">
    <h1><?php single_cat_title(); ?></h1>

    <?php if (have_posts()) : ?>
        <div class="post-list">
            <?php while (have_posts()) : the_post(); ?>
                <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
                    <header class="entry-header">
                        <h2 class="entry-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                    </header>
                    <div class="entry-content">
                        <?php the_excerpt(); ?>
                    </div>
                </article>
            <?php endwhile; ?>

            <div class="pagination">
                <?php the_posts_pagination(); ?>
            </div>
        </div>
    <?php else : ?>
        <p><?php _e('No posts found.', 'ajumapro_themes'); ?></p>
    <?php endif; ?>
</div>

<?php get_footer(); ?>
