<?php
function ajumapro_register_widgets() {
    register_sidebar(array(
        'name'          => __('Sidebar Widget Area', 'ajumapro_themes'),
        'id'            => 'sidebar-1',
        'description'   => __('Widgets in this area will be shown on the sidebar.', 'ajumapro_themes'),
        'before_widget' => '<div class="widget">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ));
}
add_action('widgets_init', 'ajumapro_register_widgets');
