<?php
// Add a custom action hook in the header
function ajumapro_before_header() {
    do_action('ajumapro_before_header');
}
add_action('ajumapro_before_header', function() {
    echo '<div class="custom-hook">This is a custom hook before the header!</div>';
});

// Add a custom filter to modify the excerpt length
function ajumapro_custom_excerpt_length($length) {
    return 20; // Set excerpt length to 20 words
}
add_filter('excerpt_length', 'ajumapro_custom_excerpt_length');
