<?php
function ajumapro_customize_register($wp_customize) {
    // Add a section for the theme options
    $wp_customize->add_section('ajumapro_theme_options', array(
        'title'    => __('Theme Options', 'ajumapro_themes'),
        'priority' => 30,
    ));

    // Add a setting for the header text color
    $wp_customize->add_setting('header_text_color', array(
        'default'   => '#000000',
        'transport' => 'refresh',
    ));

    // Add a control for the header text color
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'header_text_color_control', array(
        'label'    => __('Header Text Color', 'ajumapro_themes'),
        'section'  => 'ajumapro_theme_options',
        'settings' => 'header_text_color',
    )));
}
add_action('customize_register', 'ajumapro_customize_register');

// Apply Customizer Styles
function ajumapro_customizer_css() {
    ?>
    <style type="text/css">
        header { color: <?php echo get_theme_mod('header_text_color', '#000000'); ?>; }
    </style>
    <?php
}
add_action('wp_head', 'ajumapro_customizer_css');
