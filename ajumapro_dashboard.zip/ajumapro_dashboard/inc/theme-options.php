<?php
function ajumapro_add_theme_options_page() {
    add_menu_page(
        __('Theme Options', 'ajumapro_themes'), 
        __('Theme Options', 'ajumapro_themes'), 
        'manage_options', 
        'ajumapro-theme-options', 
        'ajumapro_render_theme_options_page',
        'dashicons-admin-generic', 
        60
    );
}
add_action('admin_menu', 'ajumapro_add_theme_options_page');

function ajumapro_render_theme_options_page() {
    ?>
    <div class="wrap">
        <h1><?php _e('Theme Options', 'ajumapro_themes'); ?></h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('ajumapro_theme_options');
            do_settings_sections('ajumapro-theme-options');
            submit_button();
            ?>
        </form>
    </div>
    <?php
}

function ajumapro_register_theme_options() {
    register_setting('ajumapro_theme_options', 'ajumapro_option');

    add_settings_section(
        'ajumapro_general_settings_section',
        __('General Settings', 'ajumapro_themes'),
        null,
        'ajumapro-theme-options'
    );

    add_settings_field(
        'ajumapro_text_option',
        __('Custom Text', 'ajumapro_themes'),
        'ajumapro_text_option_callback',
        'ajumapro-theme-options',
        'ajumapro_general_settings_section'
    );
}
add_action('admin_init', 'ajumapro_register_theme_options');

function ajumapro_text_option_callback() {
    $option = get_option('ajumapro_option');
    ?>
    <input type="text" name="ajumapro_option" value="<?php echo esc_attr($option); ?>" />
    <?php
}
