<?php
function ajumapro_enqueue_scripts() {
    // Enqueue the main stylesheet
    wp_enqueue_style('ajumapro-main-style', get_stylesheet_uri());

    // Enqueue Bootstrap (or other vendor CSS)
    wp_enqueue_style('bootstrap-css', get_template_directory_uri() . '/assets/vendors/bootstrap/css/bootstrap.min.css');

    // Enqueue custom JavaScript
    wp_enqueue_script('ajumapro-main-js', get_template_directory_uri() . '/assets/js/theme.js', array('jquery'), null, true);

    // Enqueue Bootstrap JS
    wp_enqueue_script('bootstrap-js', get_template_directory_uri() . '/assets/vendors/bootstrap/js/bootstrap.bundle.min.js', array('jquery'), null, true);
}
add_action('wp_enqueue_scripts', 'ajumapro_enqueue_scripts');
