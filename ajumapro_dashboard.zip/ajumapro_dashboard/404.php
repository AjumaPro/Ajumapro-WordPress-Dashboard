<?php
get_header(); ?>

<div class="container error-404">
    <h1><?php _e('Page Not Found', 'ajumapro_themes'); ?></h1>
    <p><?php _e('Sorry, the page you are looking for does not exist.', 'ajumapro_themes'); ?></p>
    <a href="<?php echo home_url(); ?>" class="btn-primary"><?php _e('Return to Homepage', 'ajumapro_themes'); ?></a>
</div>

<?php get_footer(); ?>
