
<aside class="sidebar">
    <?php if (is_active_sidebar('sidebar-1')) : ?>
        <div class="widget-area">
            <?php dynamic_sidebar('sidebar-1'); ?>
        </div>
    <?php endif; ?>
</aside>
