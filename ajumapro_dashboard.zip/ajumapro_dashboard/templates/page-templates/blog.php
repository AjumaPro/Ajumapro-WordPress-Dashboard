<?php
/* Template Name: Blog */
get_header(); ?>

<div class="container blog-content">
    <h1><?php _e('Blog', 'ajumapro_themes'); ?></h1>
    <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
        <div class="post-excerpt">
            <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
            <p><?php echo wp_trim_words(get_the_content(), 40); ?></p>
        </div>
    <?php endwhile; endif; ?>
    
    <div class="pagination">
        <?php the_posts_pagination(); ?>
    </div>
</div>

<?php get_footer(); ?>
