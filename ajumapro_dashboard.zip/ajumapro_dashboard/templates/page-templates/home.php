<?php
/* Template Name: Home */
get_header(); ?>

<div class="home-hero">
    <h1>Welcome to <?php bloginfo('name'); ?></h1>
    <p><?php bloginfo('description'); ?></p>
</div>

<div class="home-content">
    <div class="container">
        <?php while (have_posts()) : the_post(); ?>
            <h2><?php the_title(); ?></h2>
            <p><?php the_content(); ?></p>
        <?php endwhile; ?>
    </div>
</div>

<?php get_footer(); ?>
