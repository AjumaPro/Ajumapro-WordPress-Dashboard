<?php
// Enqueue scripts and styles
require get_template_directory() . '/inc/enqueue.php';

// Theme Customizer
require get_template_directory() . '/inc/customizer.php';

// Register widgets
require get_template_directory() . '/inc/widgets.php';

// Register WooCommerce support
function ajumapro_woocommerce_support() {
    add_theme_support('woocommerce');
}
add_action('after_setup_theme', 'ajumapro_woocommerce_support');

// Register custom menus
function ajumapro_register_menus() {
    register_nav_menus(array(
        'primary' => __('Primary Menu', 'ajumapro_themes'),
    ));
}
add_action('after_setup_theme', 'ajumapro_register_menus');

// Add theme support for featured images
add_theme_support('post-thumbnails');

// Register sidebars
function ajumapro_register_sidebar() {
    register_sidebar(array(
        'name'          => __('Main Sidebar', 'ajumapro_themes'),
        'id'            => 'sidebar-1',
        'description'   => __('Widgets in this area will be shown on all posts and pages.', 'ajumapro_themes'),
        'before_widget' => '<div class="widget">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ));
}
add_action('widgets_init', 'ajumapro_register_sidebar');
