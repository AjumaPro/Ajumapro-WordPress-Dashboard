<?php
get_header(); ?>

<div class="container search-results">
    <h1><?php _e('Search Results for:', 'ajumapro_themes'); ?> "<?php echo get_search_query(); ?>"</h1>
    <div class="row">
        <?php if(have_posts()) : while(have_posts()) : the_post(); ?>
        <div class="col-md-4 search-item">
            <a href="<?php the_permalink(); ?>"><?php the_post_thumbnail('medium'); ?></a>
            <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
            <p><?php echo wp_trim_words(get_the_excerpt(), 20); ?></p>
        </div>
        <?php endwhile; else: ?>
        <p><?php _e('No results found', 'ajumapro_themes'); ?></p>
        <?php endif; ?>
    </div>
</div>

<?php get_footer(); ?>
