<?php
/**
 * Create a Theme Options Page in the WordPress Admin.
 */

function ajumapro_add_admin_menu() {
    add_menu_page(
        __('Theme Options', 'ajumapro_themes'),
        __('Theme Options', 'ajumapro_themes'),
        'manage_options',
        'ajumapro-theme-options',
        'ajumapro_theme_options_page',
        null,
        99
    );
}

add_action('admin_menu', 'ajumapro_add_admin_menu');

function ajumapro_theme_options_page() {
?>
    <div class="wrap">
        <h1><?php _e('Theme Options', 'ajumapro_themes'); ?></h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('ajumapro_options_group');
            do_settings_sections('ajumapro-theme-options');
            submit_button();
            ?>
        </form>
    </div>
<?php
}

// Register settings for the options page
function ajumapro_register_settings() {
    register_setting('ajumapro_options_group', 'ajumapro_custom_option');

    add_settings_section('ajumapro_section', __('Custom Options', 'ajumapro_themes'), null, 'ajumapro-theme-options');

    add_settings_field('ajumapro_field', __('Custom Option', 'ajumapro_themes'), 'ajumapro_custom_option_render', 'ajumapro-theme-options', 'ajumapro_section');
}

add_action('admin_init', 'ajumapro_register_settings');

function ajumapro_custom_option_render() {
    ?>
    <input type="text" name="ajumapro_custom_option" value="<?php echo get_option('ajumapro_custom_option'); ?>" />
    <?php
}
