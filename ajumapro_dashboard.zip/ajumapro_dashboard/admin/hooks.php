<?php
/**
 * Custom hooks and filters.
 */

// Example: Add a custom class to the body tag
function ajumapro_body_classes($classes) {
    $classes[] = 'ajumapro-custom-class';
    return $classes;
}
add_filter('body_class', 'ajumapro_body_classes');

// Example: Add a custom footer message
function ajumapro_footer_message() {
    echo '<p>&copy; ' . date('Y') . ' Ajumapro Themes. All rights reserved.</p>';
}
add_action('wp_footer', 'ajumapro_footer_message');
