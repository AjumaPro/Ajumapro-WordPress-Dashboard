<?php
/**
 * Theme Customizer settings.
 */
function ajumapro_customize_register($wp_customize) {
    // Add a section for the theme options
    $wp_customize->add_section('ajumapro_theme_options', array(
        'title'    => __('Theme Options', 'ajumapro_themes'),
        'priority' => 30,
    ));

    // Add a setting for the site logo
    $wp_customize->add_setting('ajumapro_logo', array(
        'default'   => '',
        'transport' => 'refresh',
    ));

    // Add a control for the site logo
    $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'ajumapro_logo', array(
        'label'    => __('Logo', 'ajumapro_themes'),
        'section'  => 'ajumapro_theme_options',
        'settings' => 'ajumapro_logo',
    )));
}

add_action('customize_register', 'ajumapro_customize_register');
