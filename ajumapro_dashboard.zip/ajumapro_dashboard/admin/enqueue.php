<?php
/**
 * Enqueue theme styles and scripts.
 */

// Enqueue styles and scripts for front-end
function ajumapro_enqueue_styles() {

   // Enqueue Google Fonts
    wp_enqueue_style('ajumapro-google-fonts', 'https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&family=Lora:wght@400;700&display=swap', false);

    // Enqueue theme styles
    wp_enqueue_style('ajumapro-style', get_stylesheet_uri());
    wp_enqueue_style('ajumapro-main', get_template_directory_uri() . '/assets/css/main.css');
    // Enqueue scripts
    wp_enqueue_script('ajumapro-scripts', get_template_directory_uri() . '/assets/js/scripts.js', array('jquery'), '', true);
}
add_action('wp_enqueue_scripts', 'ajumapro_enqueue_styles');

// Enqueue admin styles
function ajumapro_admin_styles() {
    wp_enqueue_style('ajumapro-admin', get_template_directory_uri() . '/admin/assets/css/admin-style.css');
}
add_action('admin_enqueue_scripts', 'ajumapro_admin_styles');


function ajumapro_enqueue_vendors() {
    // Enqueue Bootstrap CSS
    wp_enqueue_style('bootstrap-css', get_template_directory_uri() . '/assets/vendors/bootstrap/css/bootstrap.min.css', array(), '5.0.0');

    // Enqueue main theme stylesheet
    wp_enqueue_style('ajumapro-style', get_stylesheet_uri());

    // Enqueue Bootstrap JS with dependency on jQuery
    wp_enqueue_script('bootstrap-js', get_template_directory_uri() . '/assets/vendors/bootstrap/js/bootstrap.min.js', array('jquery'), '5.0.0', true);

    // Enqueue main theme JS file
    wp_enqueue_script('ajumapro-scripts', get_template_directory_uri() . '/assets/js/theme.js', array('jquery'), '', true);
}

add_action('wp_enqueue_scripts', 'ajumapro_enqueue_vendors');