<?php
/**
 * Custom widget functionalities.
 */
function ajumapro_widgets_init() {
    register_sidebar(array(
        'name'          => __('Footer Widget Area', 'ajumapro_themes'),
        'id'            => 'footer-1',
        'description'   => __('Add widgets here to appear in your footer.', 'ajumapro_themes'),
        'before_widget' => '<div class="footer-widget">',
        'after_widget'  => '</div>',
        'before_title'  => '<h4 class="widget-title">',
        'after_title'   => '</h4>',
    ));
}

add_action('widgets_init', 'ajumapro_widgets_init');
