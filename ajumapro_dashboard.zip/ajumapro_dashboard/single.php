<?php
get_header(); ?>

<div class="container">
    <div class="row">
        <div class="col-md-8">
            <?php while (have_posts()) : the_post(); ?>
                <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
                    <header class="entry-header">
                        <h1 class="entry-title"><?php the_title(); ?></h1>
                        <div class="post-meta">
                            <span><?php the_time('F j, Y'); ?></span> | 
                            <span><?php the_author(); ?></span>
                        </div>
                    </header>

                    <div class="entry-content">
                        <?php the_content(); ?>
                    </div>

                    <footer class="entry-footer">
                        <span><?php _e('Categories: ', 'ajumapro_themes'); ?><?php the_category(', '); ?></span>
                    </footer>
                </article>

                <?php comments_template(); ?>
            <?php endwhile; ?>
        </div>

        <div class="col-md-4">
            <?php get_sidebar(); ?>
        </div>
    </div>
</div>

<?php get_footer(); ?>
