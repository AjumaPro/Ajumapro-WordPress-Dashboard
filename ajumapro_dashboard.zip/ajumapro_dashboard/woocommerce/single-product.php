<?php
/**
 * The Template for displaying all single products.
 */
get_header(); ?>

<div class="container woocommerce-single-product">
    <?php while ( have_posts() ) : ?>
        <?php the_post(); ?>
        <?php wc_get_template_part( 'content', 'single-product' ); ?>
    <?php endwhile; ?>
</div>

<?php get_footer(); ?>
