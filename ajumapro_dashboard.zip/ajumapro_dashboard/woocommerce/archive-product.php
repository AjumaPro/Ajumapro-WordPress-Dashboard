<?php
/**
 * The Template for displaying product archives (shop page).
 */
get_header(); ?>

<div class="container woocommerce-archive">
    <h1><?php woocommerce_page_title(); ?></h1>

    <?php if ( have_posts() ) : ?>
        <div class="products-grid">
            <?php woocommerce_product_loop_start(); ?>

            <?php while ( have_posts() ) : ?>
                <?php the_post(); ?>
                <?php wc_get_template_part( 'content', 'product' ); ?>
            <?php endwhile; ?>

            <?php woocommerce_product_loop_end(); ?>
        </div>

        <?php woocommerce_pagination(); ?>
    <?php else : ?>
        <?php wc_get_template( 'loop/no-products-found.php' ); ?>
    <?php endif; ?>
</div>

<?php get_footer(); ?>
