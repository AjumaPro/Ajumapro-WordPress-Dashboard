<?php
get_header(); // Load the header
?>

<div class="container">
    <div class="row">
        <!-- Main Content Area -->
        <div class="col-md-8">
            <?php if ( have_posts() ) : ?>
                <h1><?php _e( 'Latest Marketing Insights', 'ajumapro_themes' ); ?></h1>

                <!-- Start the Loop -->
                <?php while ( have_posts() ) : the_post(); ?>
                    <div class="post-item">
                        <a href="<?php the_permalink(); ?>">
                            <?php if ( has_post_thumbnail() ) : ?>
                                <div class="post-thumbnail">
                                    <?php the_post_thumbnail('medium'); ?>
                                </div>
                            <?php endif; ?>
                        </a>

                        <div class="post-content">
                            <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                            <div class="post-meta">
                                <span><?php _e( 'By', 'ajumapro_themes' ); ?> <?php the_author(); ?></span> | 
                                <span><?php the_time('F j, Y'); ?></span> | 
                                <span><?php _e( 'Category:', 'ajumapro_themes' ); ?> <?php the_category(', '); ?></span>
                            </div>
                            <p><?php echo wp_trim_words(get_the_excerpt(), 30); ?></p>
                            <a href="<?php the_permalink(); ?>" class="read-more-btn"><?php _e( 'Read More', 'ajumapro_themes' ); ?></a>
                        </div>
                    </div>
                <?php endwhile; ?>

                <!-- Pagination -->
                <div class="pagination">
                    <?php
                    the_posts_pagination(array(
                        'mid_size' => 2,
                        'prev_text' => __( 'Back', 'ajumapro_themes' ),
                        'next_text' => __( 'Next', 'ajumapro_themes' ),
                    ));
                    ?>
                </div>

            <?php else : ?>
                <h2><?php _e( 'No Posts Found', 'ajumapro_themes' ); ?></h2>
                <p><?php _e( 'It seems we can’t find what you’re looking for. Perhaps searching can help.', 'ajumapro_themes' ); ?></p>
                <?php get_search_form(); ?>
            <?php endif; ?>
        </div>

        <!-- Sidebar Area -->
        <div class="col-md-4">
            <?php get_sidebar(); // Load the sidebar ?>
        </div>
    </div>
</div>

<?php
get_footer(); // Load the footer
?>
